﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using InsuranceClaims.Models;

namespace InsuranceClaims.Views
{
    public class LossTypesController : Controller
    {
        private readonly AppDbContext _context;

        public LossTypesController(AppDbContext context)
        {
            _context = context;
        }

        // GET: LossTypes
        public async Task<IActionResult> Index()
        {
            var lossTypeList = new List<LossTypeView>();
            var lossTypeDb = await _context.LossTypes.ToListAsync();
            var users = await _context.Users.ToListAsync();
            foreach(LossType lt in lossTypeDb)
            {
                var updateUser = await _context.Users.FirstOrDefaultAsync(m => m.UserId == lt.LastUpdatedId);
                var createUser = await _context.Users.FirstOrDefaultAsync(m => m.UserId == lt.CreatedId);
                lossTypeList.Add(new LossTypeView
                {
                    LossTypeId = lt.LossTypeId,
                    LossTypeCode = lt.LossTypeCode,
                    LossTypeDescription = lt.LossTypeDescription,
                    Active = lt.Active,
                    LastUpdatedDate = lt.LastUpdatedDate,
                    LastUpdatedUser = updateUser != null ? updateUser.UserName : lt.LastUpdatedId.ToString(),
                    CreatedDate = lt.CreatedDate,
                    CreateUser = createUser != null ? createUser.UserName : lt.CreatedId.ToString(),
                });
            }
            return View(lossTypeList);
        }

        // GET: LossTypes/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var lossType = await _context.LossTypes
                .FirstOrDefaultAsync(m => m.LossTypeId == id);
            if (lossType == null)
            {
                return NotFound();
            }

            return View(lossType);
        }

        // GET: LossTypes/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: LossTypes/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("LossTypeId,LossTypeCode,LossTypeDescription,Active,LastUpdatedDate,LastUpdatedId,CreatedDate,CreatedId")] LossType lossType)
        {
            if (ModelState.IsValid)
            {
                _context.Add(lossType);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(lossType);
        }

        // GET: LossTypes/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var lossType = await _context.LossTypes.FindAsync(id);
            if (lossType == null)
            {
                return NotFound();
            }
            return View(lossType);
        }

        // POST: LossTypes/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("LossTypeId,LossTypeCode,LossTypeDescription,Active,LastUpdatedDate,LastUpdatedId,CreatedDate,CreatedId")] LossType lossType)
        {
            if (id != lossType.LossTypeId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(lossType);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!LossTypeExists(lossType.LossTypeId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(lossType);
        }

        // GET: LossTypes/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var lossType = await _context.LossTypes
                .FirstOrDefaultAsync(m => m.LossTypeId == id);
            if (lossType == null)
            {
                return NotFound();
            }

            return View(lossType);
        }

        // POST: LossTypes/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var lossType = await _context.LossTypes.FindAsync(id);
            _context.LossTypes.Remove(lossType);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool LossTypeExists(int id)
        {
            return _context.LossTypes.Any(e => e.LossTypeId == id);
        }
    }
}
