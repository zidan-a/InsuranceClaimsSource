﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace InsuranceClaims.Models
{
    [Table("Users")]
    public class User
    {
        [Column("UserId")]
        [Key]
        public int UserId { get; set; }

        [Column("UserName")]
        [Display(Name = "UserNameLabel", ResourceType = typeof(Resoruces.Users))]
        [Required(ErrorMessageResourceName = "UserNameRequiredErrorMessage", ErrorMessageResourceType = typeof(InsuranceClaims.Resoruces.Users))]
        public string UserName { get; set; }

        [Column("Password")]
        [Display(Name = "PasswordLabel", ResourceType = typeof(Resoruces.Users))]
        [Required(ErrorMessageResourceName = "PasswordRequiredErrorMessage", ErrorMessageResourceType = typeof(InsuranceClaims.Resoruces.Users))]
        public string Password { get; set; }
        [Column("DisplayName")]
        public string DisplayName { get; set; }
        [Column("Active")]
        public bool Active { get; set; }
    }
}
