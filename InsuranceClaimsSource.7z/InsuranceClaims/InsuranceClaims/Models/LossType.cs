﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace InsuranceClaims.Models
{
    [Table("LossTypes")]

    public class LossType
    {
        [Column("LossTypeId")]
        [Key]
        public int LossTypeId { get; set; }

        [Column("LossTypeCode")]
        [Display(Name = "LossTypeCodeLabel", ResourceType = typeof(Resoruces.LossTypes))]
        public string LossTypeCode { get; set; }

        [Column("LossTypeDescription")]
        [Display(Name = "LossTypeDescriptionLabel", ResourceType = typeof(Resoruces.LossTypes))]
        public string LossTypeDescription { get; set; }

        [Column("Active")]
        [Display(Name = "LossTypeActiveLabel", ResourceType = typeof(Resoruces.LossTypes))]
        public bool Active { get; set; }

        [Column("LastUpdatedDate")]
        [Display(Name = "LossTypeLastUpdatedDateLabel", ResourceType = typeof(Resoruces.LossTypes))]
        public DateTime LastUpdatedDate { get; set; }

        [Column("LastUpdatedId")]
        [Display(Name = "LossTypeLastUpdatedIdLabel", ResourceType = typeof(Resoruces.LossTypes))]
        public int LastUpdatedId { get; set; }

        [Column("CreatedDate")]
        [Display(Name = "LossTypeCreatedDateLabel", ResourceType = typeof(Resoruces.LossTypes))]
        public DateTime CreatedDate { get; set; }

        [Column("CreatedId")]
        [Display(Name = "LossTypeCreatedIdLabel", ResourceType = typeof(Resoruces.LossTypes))]
        public int CreatedId { get; set; }

    }
}
