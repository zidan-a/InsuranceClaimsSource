﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace InsuranceClaims.Models
{

    public class LossTypeView
    {

        public int LossTypeId { get; set; }


        [Display(Name = "LossTypeCodeLabel", ResourceType = typeof(Resoruces.LossTypes))]
        public string LossTypeCode { get; set; }


        [Display(Name = "LossTypeDescriptionLabel", ResourceType = typeof(Resoruces.LossTypes))]
        public string LossTypeDescription { get; set; }


        [Display(Name = "LossTypeActiveLabel", ResourceType = typeof(Resoruces.LossTypes))]
        public bool Active { get; set; }


        [Display(Name = "LossTypeLastUpdatedDateLabel", ResourceType = typeof(Resoruces.LossTypes))]
        public DateTime LastUpdatedDate { get; set; }


        [Display(Name = "LossTypeLastUpdatedIdLabel", ResourceType = typeof(Resoruces.LossTypes))]
        public string LastUpdatedUser { get; set; }

        [Column("CreatedDate")]
        [Display(Name = "LossTypeCreatedDateLabel", ResourceType = typeof(Resoruces.LossTypes))]
        public DateTime CreatedDate { get; set; }

        [Column("CreatedId")]
        [Display(Name = "LossTypeCreatedIdLabel", ResourceType = typeof(Resoruces.LossTypes))]
        public string CreateUser { get; set; }

    }
}
